# 🚀 تعليمات النشر - أبو زوك فيديو

## خيارات النشر السريعة

### 1️⃣ النشر على Railway (الأسهل والأسرع)

#### الخطوات:

1. **إنشاء حساب على Railway:**
   - اذهب إلى https://railway.app
   - سجل دخول باستخدام GitHub

2. **ربط المشروع:**
   ```bash
   npm install -g @railway/cli
   railway login
   railway link
   ```

3. **تعيين متغيرات البيئة:**
   ```bash
   railway variable add NODE_ENV production
   railway variable add JWT_SECRET your-secret-key
   railway variable add DATABASE_URL postgresql://...
   railway variable add REDIS_URL redis://...
   ```

4. **النشر:**
   ```bash
   railway up
   ```

5. **الوصول إلى التطبيق:**
   - سيحصل على URL تلقائي من Railway
   - مثال: `https://abu-zook-video.railway.app`

---

### 2️⃣ النشر على Render

#### الخطوات:

1. **إنشاء حساب على Render:**
   - اذهب إلى https://render.com
   - سجل دخول باستخدام GitHub

2. **ربط المشروع:**
   - انقر على "New +" 
   - اختر "Web Service"
   - اختر المشروع من GitHub

3. **الإعدادات:**
   - **Name:** abu-zook-video
   - **Environment:** Node
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`

4. **متغيرات البيئة:**
   - أضف جميع المتغيرات من `.env.example`

5. **النشر:**
   - انقر على "Deploy"
   - سيتم النشر تلقائياً

---

### 3️⃣ النشر على Heroku

#### الخطوات:

1. **تثبيت Heroku CLI:**
   ```bash
   npm install -g heroku
   heroku login
   ```

2. **إنشاء تطبيق:**
   ```bash
   heroku create abu-zook-video
   ```

3. **إضافة قاعدة البيانات:**
   ```bash
   heroku addons:create heroku-postgresql:standard-0
   heroku addons:create heroku-redis:premium-0
   ```

4. **تعيين متغيرات البيئة:**
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set JWT_SECRET=your-secret-key
   ```

5. **النشر:**
   ```bash
   git push heroku main
   heroku run npx prisma migrate deploy
   ```

---

### 4️⃣ النشر على AWS

#### استخدام Elastic Beanstalk:

```bash
# تثبيت EB CLI
pip install awsebcli

# إنشاء تطبيق
eb init -p "Node.js 18 running on 64bit Amazon Linux 2" abu-zook-video

# إنشاء بيئة
eb create production

# النشر
eb deploy
```

---

### 5️⃣ النشر على DigitalOcean

#### استخدام App Platform:

1. اذهب إلى https://cloud.digitalocean.com/apps
2. انقر على "Create App"
3. اختر المشروع من GitHub
4. اتبع الخطوات
5. أضف متغيرات البيئة
6. انقر على "Deploy"

---

## النشر باستخدام Docker

### بناء الصور:

```bash
# Backend
docker build -t abu-zook-backend:latest ./backend

# Frontend
docker build -t abu-zook-frontend:latest ./frontend
```

### تشغيل الحاويات:

```bash
docker-compose -f docker-compose.prod.yml up -d
```

### دفع الصور إلى Docker Hub:

```bash
docker login
docker tag abu-zook-backend:latest your-username/abu-zook-backend:latest
docker push your-username/abu-zook-backend:latest
```

---

## CI/CD التلقائي

### GitHub Actions

ملف `.github/workflows/deploy.yml` يقوم بـ:
- بناء المشروع تلقائياً
- تشغيل الاختبارات
- النشر على Railway/Render

### متطلبات الأسرار:

أضف هذه الأسرار في GitHub Settings:

```
RAILWAY_TOKEN=your-railway-token
RAILWAY_PROJECT_ID=your-project-id
RENDER_DEPLOY_HOOK=your-render-hook
SLACK_WEBHOOK=your-slack-webhook
```

---

## إعدادات الإنتاج

### متغيرات البيئة الحساسة:

```bash
NODE_ENV=production
JWT_SECRET=generate-strong-key
JWT_REFRESH_SECRET=generate-strong-key
DATABASE_URL=postgresql://user:password@host/db
REDIS_URL=redis://host:6379
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
CORS_ORIGIN=https://yourdomain.com
```

### الأمان:

- ✅ استخدم HTTPS فقط
- ✅ فعّل CORS بشكل صحيح
- ✅ استخدم كلمات مرور قوية
- ✅ فعّل Rate Limiting
- ✅ استخدم WAF (Web Application Firewall)

### الأداء:

- ✅ استخدم CDN (CloudFront, Cloudflare)
- ✅ فعّل Caching
- ✅ استخدم Load Balancer
- ✅ راقب الأداء

---

## المراقبة والسجلات

### عرض السجلات:

```bash
# Railway
railway logs

# Render
render logs

# Heroku
heroku logs --tail

# Docker
docker logs abu_zook_backend
```

### المراقبة:

- استخدم Sentry للأخطاء
- استخدم DataDog للمراقبة
- استخدم New Relic للأداء

---

## استكشاف الأخطاء

### خطأ: Database Connection Failed

```bash
# تحقق من متغيرات البيئة
heroku config
railway variable list

# اختبر الاتصال
psql $DATABASE_URL -c "SELECT 1"
```

### خطأ: Out of Memory

```bash
# زيادة حد الذاكرة
NODE_OPTIONS=--max-old-space-size=2048
```

### خطأ: Port Already in Use

```bash
# استخدم منفذ مختلف
PORT=3001 npm start
```

---

## قائمة التحقق قبل النشر

- [ ] جميع الاختبارات تمر
- [ ] لا توجد أخطاء TypeScript
- [ ] متغيرات البيئة مضبوطة
- [ ] قاعدة البيانات معدة
- [ ] النسخ الاحتياطية مفعلة
- [ ] المراقبة مفعلة
- [ ] HTTPS مفعل
- [ ] CORS مضبوط
- [ ] Rate Limiting مفعل
- [ ] السجلات مفعلة

---

## الدعم

للمساعدة:
- 📧 support@abuzookvideo.com
- 📖 docs/
- 🐛 GitHub Issues

---

**آخر تحديث:** نوفمبر 2024
