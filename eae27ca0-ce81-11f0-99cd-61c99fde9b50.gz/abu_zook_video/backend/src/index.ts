import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';

// Load environment variables
dotenv.config();

const app: Express = express();
const httpServer = createServer(app);
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: process.env.CORS_ORIGIN?.split(',') || ['http://localhost:3000'],
    credentials: true,
  },
});

const PORT = process.env.BACKEND_PORT || 3001;

// ============================================
// Middleware
// ============================================

// Security
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',') || ['http://localhost:3000'],
  credentials: true,
}));

// Body parsing
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// ============================================
// Routes
// ============================================

app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'OK',
    message: 'Abu Zook Video API is running',
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/docs', (req: Request, res: Response) => {
  res.json({
    name: 'Abu Zook Video API',
    version: '1.0.0',
    description: 'Short-form video platform API',
    endpoints: {
      auth: '/api/auth',
      users: '/api/users',
      videos: '/api/videos',
      comments: '/api/comments',
      likes: '/api/likes',
      follows: '/api/follows',
      chats: '/api/chats',
      messages: '/api/messages',
      admin: '/api/admin',
    },
  });
});

// ============================================
// WebSocket Events
// ============================================

io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);

  // Chat events
  socket.on('join-chat', (chatId) => {
    socket.join(`chat-${chatId}`);
    console.log(`User ${socket.id} joined chat ${chatId}`);
  });

  socket.on('send-message', (data) => {
    io.to(`chat-${data.chatId}`).emit('new-message', data);
  });

  socket.on('typing', (data) => {
    io.to(`chat-${data.chatId}`).emit('user-typing', {
      userId: data.userId,
      isTyping: data.isTyping,
    });
  });

  // Notification events
  socket.on('subscribe-notifications', (userId) => {
    socket.join(`user-${userId}`);
  });

  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
  });
});

// ============================================
// Error Handling
// ============================================

app.use((err: any, req: Request, res: Response) => {
  console.error(err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    timestamp: new Date().toISOString(),
  });
});

// ============================================
// Start Server
// ============================================

httpServer.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║  🎬✨ Abu Zook Video API 🎬✨         ║
║  Server running on port ${PORT}        ║
║  Environment: ${process.env.NODE_ENV || 'development'}         ║
║  Health Check: http://localhost:${PORT}/health  ║
║  API Docs: http://localhost:${PORT}/api/docs    ║
╚════════════════════════════════════════╝
  `);
});

export { app, httpServer, io };
