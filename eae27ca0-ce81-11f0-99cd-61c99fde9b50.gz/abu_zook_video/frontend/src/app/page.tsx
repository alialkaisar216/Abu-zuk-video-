'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false)

  const stats = [
    { number: '10M+', label: 'مستخدم نشط' },
    { number: '500M+', label: 'فيديو' },
    { number: '1B+', label: 'مشاهدة يومية' },
  ]

  const features = [
    {
      icon: '🎥',
      title: 'فيديوهات قصيرة',
      description: 'شارك فيديوهات قصيرة مبتكرة مع العالم'
    },
    {
      icon: '💬',
      title: 'تفاعل مباشر',
      description: 'تعليقات وإعجابات ومشاركة فورية'
    },
    {
      icon: '👥',
      title: 'متابعة المبدعين',
      description: 'تابع المبدعين المفضلين لديك'
    },
    {
      icon: '🎵',
      title: 'موسيقى وتأثيرات',
      description: 'أضف موسيقى وتأثيرات احترافية'
    },
    {
      icon: '📊',
      title: 'إحصائيات مفصلة',
      description: 'تابع أداء فيديوهاتك'
    },
    {
      icon: '🛡️',
      title: 'آمن وموثوق',
      description: 'حماية كاملة لبيانات المستخدمين'
    },
  ]

  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 backdrop-blur-md bg-black/50 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center gap-2 text-2xl font-bold text-gradient">
            🎬✨ أبو زوك فيديو
          </div>
          <div className="hidden md:flex items-center gap-4">
            <Link href="/login" className="btn-secondary">
              دخول
            </Link>
            <Link href="/register" className="btn-primary">
              إنشاء حساب
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Background Animation */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl -top-20 -left-20 animate-pulse"></div>
          <div className="absolute w-96 h-96 bg-pink-500/20 rounded-full blur-3xl -bottom-20 -right-20 animate-pulse"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-slide-up">
            <span className="text-gradient">أبو زوك فيديو</span>
            <br />
            <span className="text-white">منصة الفيديو القصيرة</span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto animate-fade-in">
            شارك إبداعك مع ملايين المستخدمين حول العالم. فيديوهات قصيرة، محتوى مذهل، تفاعل لا محدود
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12 animate-fade-in">
            <Link href="/register" className="btn-primary text-lg px-8 py-3">
              ابدأ الآن
            </Link>
            <Link href="/feed" className="btn-secondary text-lg px-8 py-3">
              استكشف الفيديوهات
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-16">
            {stats.map((stat, index) => (
              <div key={index} className="card">
                <div className="text-3xl md:text-4xl font-bold text-gradient">{stat.number}</div>
                <div className="text-sm text-gray-400 mt-2">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
            <span className="text-gradient">المميزات الرائعة</span>
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="card hover:scale-105 transition-transform">
                <div className="text-5xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center card">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            هل أنت مستعد لبدء رحلتك الإبداعية؟
          </h2>
          <p className="text-gray-300 mb-8 text-lg">
            انضم إلى ملايين المبدعين والمشاهدين على منصة أبو زوك فيديو
          </p>
          <Link href="/register" className="btn-primary text-lg px-8 py-3 inline-block">
            إنشاء حساب مجاني الآن
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">عن المنصة</h4>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">حول أبو زوك</a></li>
                <li><a href="#" className="hover:text-white transition">الأخبار</a></li>
                <li><a href="#" className="hover:text-white transition">الوظائف</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">المساعدة</h4>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">مركز المساعدة</a></li>
                <li><a href="#" className="hover:text-white transition">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-white transition">التواصل</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">القانوني</h4>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-white transition">شروط الخدمة</a></li>
                <li><a href="#" className="hover:text-white transition">ملفات تعريف الارتباط</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">تابعنا</h4>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Twitter</a></li>
                <li><a href="#" className="hover:text-white transition">Instagram</a></li>
                <li><a href="#" className="hover:text-white transition">TikTok</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 أبو زوك فيديو 🎬✨ - جميع الحقوق محفوظة</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
