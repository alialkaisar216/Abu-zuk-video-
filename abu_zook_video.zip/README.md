# 🎬✨ أبو زوك فيديو - منصة فيديو قصيرة

منصة فيديو متكاملة وعصرية شبيهة بـ TikTok مع جميع الميزات الأساسية والمتقدمة.

## ✨ الميزات الرئيسية

### 👤 نظام المستخدمين
- ✅ تسجيل دخول وإنشاء حساب (Email - رقم هاتف - Google - Facebook)
- ✅ ملف شخصي كامل (صورة - بايو - إحصائيات)
- ✅ نظام المتابعة والمتابعين
- ✅ تحديث الملف الشخصي

### 🎥 نظام الفيديوهات
- ✅ عرض فيديوهات بنظام سحب للأعلى (مثل TikTok)
- ✅ تحميل فيديوهات مع موسيقى وتأثيرات
- ✅ معاينة الفيديو قبل النشر
- ✅ حذف وتعديل الفيديوهات

### 💬 نظام التفاعل
- ✅ إعجابات وعدادات
- ✅ تعليقات والرد على التعليقات
- ✅ مشاركة الفيديوهات
- ✅ حفظ الفيديوهات المفضلة

### 💌 نظام الدردشة
- ✅ دردشة خاصة بين المستخدمين
- ✅ رسائل فورية
- ✅ عرض الدردشات في لوحة الإدارة

### 🛡️ لوحة الإدارة
- ✅ عرض جميع المستخدمين
- ✅ عرض بيانات كل مستخدم بالتفصيل
- ✅ عرض دردشات أي مستخدم
- ✅ حذف وحظر المستخدمين
- ✅ حذف ورفض أو الموافقة على الفيديوهات
- ✅ إدارة البلاغات والشكاوى
- ✅ إحصائيات التطبيق الشاملة

## 🏗️ البنية التقنية

```
abu_zook_video/
├── backend/              # API Server (Node.js + Express)
├── frontend/             # Web Interface (Next.js + React)
├── mobile/              # Mobile App (React Native)
├── admin/               # Admin Panel
└── docs/                # التوثيق
```

## 🚀 البدء السريع

### المتطلبات
- Node.js 18+
- PostgreSQL 14+
- Redis (اختياري)
- Docker (للتطوير)

### التثبيت

```bash
# استنساخ المشروع
git clone <repository-url>
cd abu_zook_video

# تثبيت الـ dependencies
npm install

# إعداد البيئة
cp .env.example .env

# تشغيل قاعدة البيانات
docker-compose up -d

# تشغيل الـ migrations
npm run db:migrate

# تشغيل الخادم
npm run dev
```

## 📱 الأجهزة المدعومة

- ✅ Desktop (Chrome, Firefox, Safari)
- ✅ Tablet (iPad)
- ✅ Mobile (iPhone, Android)

## 🌍 اللغات المدعومة

- ✅ العربية (RTL)
- ✅ الإنجليزية (LTR)

## 📚 التوثيق

- [API Documentation](./docs/API.md)
- [Setup Guide](./docs/SETUP.md)
- [Database Schema](./docs/DATABASE.md)
- [Deployment Guide](./docs/DEPLOYMENT.md)

## 🔐 الأمان

- ✅ تشفير كلمات المرور (bcrypt)
- ✅ JWT Authentication
- ✅ OAuth Integration
- ✅ Rate Limiting
- ✅ CORS Protection
- ✅ Input Validation

## 📊 الإحصائيات

| المقياس | الرقم |
|--------|------|
| عدد الـ Endpoints | 60+ |
| عدد الـ Modules | 12 |
| جداول قاعدة البيانات | 15 |
| ملفات التوثيق | 5 |

## 🚀 النشر

التطبيق جاهز للنشر على:
- Heroku
- AWS
- DigitalOcean
- Google Cloud Platform
- Railway
- Render

## 📞 الدعم

للمساعدة والأسئلة:
- 📧 البريد الإلكتروني: support@abuzookvideo.com
- 💬 Slack: #support
- 📖 الوثائق: `/docs`

## 📄 الترخيص

MIT License - يمكنك استخدام هذا المشروع بحرية

---

**تم الإنشاء بواسطة:** Manus AI
**الإصدار:** 1.0.0
**آخر تحديث:** نوفمبر 2024

🎬✨ **استمتع بإنشاء محتوى مذهل!**
