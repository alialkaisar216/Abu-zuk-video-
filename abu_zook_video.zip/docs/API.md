# 📚 API Documentation - Abu Zook Video

## Base URL
```
http://localhost:3001/api
```

## Authentication
All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

---

## 🔐 Authentication Endpoints

### Register
```
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "phone": "+20123456789",
  "username": "username",
  "displayName": "Display Name",
  "password": "password123"
}

Response: { token, refreshToken, user }
```

### Login
```
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}

Response: { token, refreshToken, user }
```

### Login with Phone
```
POST /auth/login-phone
Content-Type: application/json

{
  "phone": "+20123456789",
  "password": "password123"
}

Response: { token, refreshToken, user }
```

### Send OTP
```
POST /auth/send-otp
Content-Type: application/json

{
  "email": "user@example.com"
}

Response: { message: "OTP sent" }
```

### Verify OTP
```
POST /auth/verify-otp
Content-Type: application/json

{
  "email": "user@example.com",
  "code": "123456"
}

Response: { token, refreshToken, user }
```

### Google OAuth
```
POST /auth/google
Content-Type: application/json

{
  "token": "google_id_token"
}

Response: { token, refreshToken, user }
```

### Facebook OAuth
```
POST /auth/facebook
Content-Type: application/json

{
  "accessToken": "facebook_access_token"
}

Response: { token, refreshToken, user }
```

### Refresh Token
```
POST /auth/refresh
Content-Type: application/json

{
  "refreshToken": "refresh_token"
}

Response: { token, refreshToken }
```

---

## 👤 User Endpoints

### Get Current User
```
GET /users/me
Authorization: Bearer <token>

Response: { id, email, username, displayName, profileImage, ... }
```

### Get User by ID
```
GET /users/:id

Response: { id, email, username, displayName, profileImage, ... }
```

### Get User by Username
```
GET /users/username/:username

Response: { id, email, username, displayName, profileImage, ... }
```

### Update Profile
```
PUT /users/me
Authorization: Bearer <token>
Content-Type: application/json

{
  "displayName": "New Name",
  "bio": "New bio",
  "profileImage": "image_url"
}

Response: { updated user }
```

### Search Users
```
GET /users/search?q=query&limit=10&offset=0

Response: { users: [...], total }
```

### Get User Statistics
```
GET /users/:id/stats

Response: {
  videosCount,
  followersCount,
  followingCount,
  totalLikes,
  totalViews
}
```

---

## 🎥 Video Endpoints

### Get Feed Videos
```
GET /videos/feed?limit=10&offset=0
Authorization: Bearer <token>

Response: { videos: [...], total }
```

### Get Trending Videos
```
GET /videos/trending?limit=10&offset=0

Response: { videos: [...], total }
```

### Get Video by ID
```
GET /videos/:id

Response: { id, title, description, videoUrl, views, likes, ... }
```

### Get User Videos
```
GET /videos/user/:userId?limit=10&offset=0

Response: { videos: [...], total }
```

### Upload Video
```
POST /videos/upload
Authorization: Bearer <token>
Content-Type: multipart/form-data

{
  "file": <video_file>,
  "title": "Video Title",
  "description": "Video Description",
  "thumbnail": <image_file>
}

Response: { id, status: "PROCESSING", ... }
```

### Update Video
```
PUT /videos/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "New Title",
  "description": "New Description",
  "allowComments": true
}

Response: { updated video }
```

### Delete Video
```
DELETE /videos/:id
Authorization: Bearer <token>

Response: { message: "Video deleted" }
```

### Search Videos
```
GET /videos/search?q=query&limit=10&offset=0

Response: { videos: [...], total }
```

---

## 💬 Comment Endpoints

### Get Video Comments
```
GET /comments/video/:videoId?limit=10&offset=0

Response: { comments: [...], total }
```

### Create Comment
```
POST /comments
Authorization: Bearer <token>
Content-Type: application/json

{
  "videoId": "video_id",
  "content": "Comment text",
  "parentId": "parent_comment_id" (optional)
}

Response: { id, content, userId, videoId, ... }
```

### Update Comment
```
PUT /comments/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "content": "Updated comment"
}

Response: { updated comment }
```

### Delete Comment
```
DELETE /comments/:id
Authorization: Bearer <token>

Response: { message: "Comment deleted" }
```

---

## ❤️ Like Endpoints

### Like Video
```
POST /likes
Authorization: Bearer <token>
Content-Type: application/json

{
  "videoId": "video_id"
}

Response: { id, userId, videoId, ... }
```

### Unlike Video
```
DELETE /likes/:videoId
Authorization: Bearer <token>

Response: { message: "Like removed" }
```

### Get Video Likes
```
GET /likes/video/:videoId?limit=10&offset=0

Response: { likes: [...], total }
```

### Check if Liked
```
GET /likes/check/:videoId
Authorization: Bearer <token>

Response: { isLiked: true/false }
```

---

## 🔖 Bookmark Endpoints

### Save Video
```
POST /bookmarks
Authorization: Bearer <token>
Content-Type: application/json

{
  "videoId": "video_id"
}

Response: { id, userId, videoId, ... }
```

### Remove Bookmark
```
DELETE /bookmarks/:videoId
Authorization: Bearer <token>

Response: { message: "Bookmark removed" }
```

### Get Saved Videos
```
GET /bookmarks/me?limit=10&offset=0
Authorization: Bearer <token>

Response: { videos: [...], total }
```

---

## 👥 Follow Endpoints

### Follow User
```
POST /follows
Authorization: Bearer <token>
Content-Type: application/json

{
  "followingId": "user_id"
}

Response: { id, followerId, followingId, ... }
```

### Unfollow User
```
DELETE /follows/:followingId
Authorization: Bearer <token>

Response: { message: "Unfollowed" }
```

### Get Followers
```
GET /follows/followers/:userId?limit=10&offset=0

Response: { followers: [...], total }
```

### Get Following
```
GET /follows/following/:userId?limit=10&offset=0

Response: { following: [...], total }
```

### Check if Following
```
GET /follows/check/:userId
Authorization: Bearer <token>

Response: { isFollowing: true/false }
```

---

## 💌 Chat Endpoints (New)

### Get User Chats
```
GET /chats/me
Authorization: Bearer <token>

Response: { chats: [...] }
```

### Create Chat
```
POST /chats
Authorization: Bearer <token>
Content-Type: application/json

{
  "participantId": "user_id"
}

Response: { id, participants, createdAt, ... }
```

### Get Chat Messages
```
GET /chats/:chatId/messages?limit=50&offset=0
Authorization: Bearer <token>

Response: { messages: [...], total }
```

### Send Message
```
POST /chats/:chatId/messages
Authorization: Bearer <token>
Content-Type: application/json

{
  "content": "Message text"
}

Response: { id, content, senderId, chatId, ... }
```

### Mark Message as Read
```
PUT /chats/:chatId/messages/:messageId/read
Authorization: Bearer <token>

Response: { updated message }
```

### Delete Message
```
DELETE /chats/:chatId/messages/:messageId
Authorization: Bearer <token>

Response: { message: "Message deleted" }
```

---

## 📊 Admin Endpoints

### Get All Users
```
GET /admin/users?limit=10&offset=0&search=query
Authorization: Bearer <admin_token>

Response: { users: [...], total }
```

### Get User Details
```
GET /admin/users/:userId
Authorization: Bearer <admin_token>

Response: { user details with all info }
```

### Ban User
```
POST /admin/users/:userId/ban
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "reason": "Ban reason"
}

Response: { message: "User banned" }
```

### Unban User
```
POST /admin/users/:userId/unban
Authorization: Bearer <admin_token>

Response: { message: "User unbanned" }
```

### Get All Videos
```
GET /admin/videos?limit=10&offset=0&status=PENDING
Authorization: Bearer <admin_token>

Response: { videos: [...], total }
```

### Approve Video
```
POST /admin/videos/:videoId/approve
Authorization: Bearer <admin_token>

Response: { message: "Video approved" }
```

### Reject Video
```
POST /admin/videos/:videoId/reject
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "reason": "Rejection reason"
}

Response: { message: "Video rejected" }
```

### Delete Video
```
DELETE /admin/videos/:videoId
Authorization: Bearer <admin_token>

Response: { message: "Video deleted" }
```

### Get Reports
```
GET /admin/reports?limit=10&offset=0&status=PENDING
Authorization: Bearer <admin_token>

Response: { reports: [...], total }
```

### Resolve Report
```
POST /admin/reports/:reportId/resolve
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "action": "APPROVE|REJECT",
  "resolution": "Resolution details"
}

Response: { updated report }
```

### Get Statistics
```
GET /admin/stats
Authorization: Bearer <admin_token>

Response: {
  totalUsers,
  totalVideos,
  totalComments,
  totalLikes,
  activeUsers,
  ...
}
```

### View User Chats
```
GET /admin/users/:userId/chats
Authorization: Bearer <admin_token>

Response: { chats: [...] }
```

### View Chat Messages
```
GET /admin/chats/:chatId/messages
Authorization: Bearer <admin_token>

Response: { messages: [...] }
```

---

## Error Responses

All error responses follow this format:
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "statusCode": 400,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### Common Error Codes
- `INVALID_CREDENTIALS` - Invalid email/password
- `USER_NOT_FOUND` - User does not exist
- `VIDEO_NOT_FOUND` - Video does not exist
- `UNAUTHORIZED` - Missing or invalid token
- `FORBIDDEN` - Insufficient permissions
- `VALIDATION_ERROR` - Invalid input data
- `RATE_LIMIT_EXCEEDED` - Too many requests
- `INTERNAL_SERVER_ERROR` - Server error

---

## Rate Limiting

- **Default:** 100 requests per 15 minutes
- **Auth endpoints:** 5 requests per 15 minutes
- **Upload endpoints:** 10 requests per hour

---

**Last Updated:** November 2024
