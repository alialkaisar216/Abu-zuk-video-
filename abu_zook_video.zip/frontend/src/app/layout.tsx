import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'أبو زوك فيديو 🎬✨ - منصة الفيديو القصيرة',
  description: 'منصة فيديو قصيرة متكاملة مثل TikTok مع جميع الميزات الأساسية والمتقدمة',
  keywords: ['فيديو', 'تيك توك', 'منصة', 'محتوى', 'إبداع'],
  openGraph: {
    title: 'أبو زوك فيديو 🎬✨',
    description: 'منصة فيديو قصيرة متكاملة',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='75' font-size='75' fill='%2325f4ee'>🎬</text></svg>" />
      </head>
      <body className="bg-black text-white">
        <div className="min-h-screen">
          {children}
        </div>
      </body>
    </html>
  )
}
